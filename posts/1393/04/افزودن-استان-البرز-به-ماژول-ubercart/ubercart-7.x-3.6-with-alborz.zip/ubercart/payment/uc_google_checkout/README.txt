The Google Checkout module has been removed from Ubercart.
    
As per https://support.google.com/checkout/sell/answer/3080449,
Google Checkout is no longer in operation as of 20 November 2013 and
can no longer be used as a payment method. Therefore, we've removed
the uc_google_checkout module entirely.

A skeleton module has been left in place to allow you to UNINSTALL
uc_google_checkout from any site where you had it running. Be sure
to follow the three steps in https://drupal.org/node/2145671 to
completely uninstall the uc_google_checkout module from your site.
You may delete the ubercart/uc_google_checkout directory and all its
contents after you competely uninstall it.
